/// <summary>
    /// 
    /// </summary>
public interface ISelectable
{
    void OnSelect();
    void ToggleOutline(bool isEnabled);
}
