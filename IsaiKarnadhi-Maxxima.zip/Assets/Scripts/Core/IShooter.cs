/// <summary>
/// 
/// </summary>
public interface IShooter
{
    void Shoot();
    void CalculateDamage();
}
