/// <summary>
/// 
/// </summary>
public interface IUnit : IShooter, ISelectable
{
    
}
