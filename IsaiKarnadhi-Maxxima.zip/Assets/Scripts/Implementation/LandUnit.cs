using UnityEngine;

public class LandUnit : Unit
{
}