using UnityEngine;

/// <summary>
/// 
/// </summary>
public class Unit : MonoBehaviour, IUnit
{
    /// <summary>
    /// 
    /// </summary>
    public void Shoot()
    {
        Debug.Log(gameObject.name + "Shoot");

    }

    /// <summary>
    /// 
    /// </summary>
    public void CalculateDamage()
    {

    }

    public void OnSelect()
    {

    }

    public void ToggleOutline(bool isEnabled)
    {

    }
}