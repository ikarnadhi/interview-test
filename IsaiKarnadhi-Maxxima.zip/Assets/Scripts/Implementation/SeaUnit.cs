using UnityEngine;

public class SeaUnit : Unit
{
}