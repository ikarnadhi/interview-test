using UnityEngine;

public class AirUnit : Unit
{
}